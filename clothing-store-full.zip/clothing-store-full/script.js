// === КОШИК ===
let cartItems = JSON.parse(localStorage.getItem("cartItems") || "[]");
let cartCountElement = document.getElementById("cart-count");
let cartListElement = document.createElement("div");
cartListElement.id = "cart-items";
document.getElementById("cart").appendChild(cartListElement);

function updateCart() {
  cartCountElement.textContent = cartItems.length;
  cartListElement.innerHTML = "";
  const map = {};
  let total = 0;

  cartItems.forEach((item) => {
    if (!map[item.name]) map[item.name] = { ...item, count: 0 };
    map[item.name].count++;
    total += item.price;
  });

  for (let name in map) {
    const div = document.createElement("div");
    div.textContent = `${name} — ${map[name].count} шт — ${map[name].price * map[name].count} грн`;
    cartListElement.appendChild(div);
  }

  if (cartItems.length > 0) {
    const totalDiv = document.createElement("div");
    totalDiv.innerHTML = `<strong>Разом: ${total} грн</strong>`;
    cartListElement.appendChild(totalDiv);
  }

  localStorage.setItem("cartItems", JSON.stringify(cartItems));
}

document.querySelectorAll(".add-to-cart").forEach((button) => {
  button.addEventListener("click", () => {
    const product = button.closest(".product");
    const name = product.dataset.name;
    const price = parseFloat(product.dataset.price);
    cartItems.push({ name, price });
    updateCart();
    showNotification(`"${name}" додано до кошика`);
  });
});

updateCart();

// === ОБРАНЕ ===
let likedItems = JSON.parse(localStorage.getItem("likedItems") || "[]");

document.querySelectorAll(".like-btn").forEach((btn) => {
  const product = btn.closest(".product");
  const name = product.dataset.name;

  if (likedItems.includes(name)) btn.classList.add("liked");

  btn.addEventListener("click", () => {
    if (likedItems.includes(name)) {
      likedItems = likedItems.filter((n) => n !== name);
      btn.classList.remove("liked");
    } else {
      likedItems.push(name);
      btn.classList.add("liked");
    }
    localStorage.setItem("likedItems", JSON.stringify(likedItems));
  });
});

document.getElementById("show-liked").addEventListener("click", () => {
  const products = document.querySelectorAll(".product");
  products.forEach((p) => {
    const name = p.dataset.name;
    p.style.display = likedItems.includes(name) ? "block" : "none";
  });
  showNotification("Показано лише обрані товари");
});

// === СЛАЙДЕР ===
let slideIndex = 0;
const slides = document.querySelectorAll(".slide");
function showSlides() {
  slides.forEach((s) => s.classList.remove("active"));
  slideIndex = (slideIndex + 1) % slides.length;
  slides[slideIndex].classList.add("active");
}
setInterval(showSlides, 3000);

// === ТЕМА ===
document.getElementById("theme-toggle").addEventListener("change", () => {
  document.body.classList.toggle("dark-theme");
});

// === МОДАЛЬНЕ ВІКНО ===
const modal = document.getElementById("modal");
const modalImg = document.getElementById("modal-img");
const modalTitle = document.getElementById("modal-title");
const modalPrice = document.getElementById("modal-price");
const modalAdd = document.getElementById("modal-add");
let modalProduct = null;

document.querySelectorAll(".product img").forEach((img) => {
  img.style.cursor = "pointer";
  img.addEventListener("click", () => {
    const product = img.closest(".product");
    modalProduct = product;
    modalImg.src = img.src;
    modalTitle.textContent = product.dataset.name;
    modalPrice.textContent = product.querySelector("p").textContent;
    modal.style.display = "block";
  });
});

document.querySelector(".close-button").onclick = () => {
  modal.style.display = "none";
};

modalAdd.onclick = () => {
  if (modalProduct) {
    const name = modalProduct.dataset.name;
    const price = parseFloat(modalProduct.dataset.price);
    cartItems.push({ name, price });
    updateCart();
    modal.style.display = "none";
    showNotification(`"${name}" додано до кошика`);
  }
};

// === ВІДГУКИ ===
document.querySelectorAll(".submit-review").forEach((btn) => {
  btn.addEventListener("click", () => {
    const product = btn.closest(".product");
    const textarea = product.querySelector("textarea");
    const reviewList = product.querySelector(".review-list");

    if (textarea.value.trim()) {
      const p = document.createElement("p");
      p.textContent = textarea.value;
      reviewList.appendChild(p);
      textarea.value = "";
      showNotification("Відгук надіслано!");
    }
  });
});

// === ФІЛЬТРИ (пошук, категорія, ціна) ===
const searchInput = document.getElementById("search");
const categoryFilter = document.getElementById("category-filter");
const priceFrom = document.getElementById("price-from");
const priceTo = document.getElementById("price-to");
const resetFiltersBtn = document.getElementById("reset-filters");
const products = document.querySelectorAll(".product");

function filterProducts() {
  const search = searchInput.value.toLowerCase();
  const category = categoryFilter.value;
  const from = parseFloat(priceFrom.value) || 0;
  const to = parseFloat(priceTo.value) || Infinity;

  products.forEach((product) => {
    const name = product.dataset.name.toLowerCase();
    const cat = product.dataset.category;
    const price = parseFloat(product.dataset.price);

    const matchName = name.includes(search);
    const matchCat = category === "all" || cat === category;
    const matchPrice = price >= from && price <= to;

    product.style.display = matchName && matchCat && matchPrice ? "block" : "none";
  });
}

searchInput.addEventListener("input", filterProducts);
categoryFilter.addEventListener("change", filterProducts);
priceFrom.addEventListener("input", filterProducts);
priceTo.addEventListener("input", filterProducts);

// === ОЧИСТИТИ ФІЛЬТРИ ===
resetFiltersBtn.addEventListener("click", () => {
  searchInput.value = "";
  categoryFilter.value = "all";
  priceFrom.value = "";
  priceTo.value = "";
  products.forEach(p => p.style.display = "block");
  showNotification("Фільтри скинуто");
});

// === СОРТУВАННЯ ===
document.getElementById("sort-select").addEventListener("change", () => {
  const sortValue = document.getElementById("sort-select").value;
  const productList = document.getElementById("product-list");
  const productElements = Array.from(productList.children);

  productElements.sort((a, b) => {
    const priceA = parseFloat(a.dataset.price);
    const priceB = parseFloat(b.dataset.price);
    return sortValue === "asc" ? priceA - priceB : priceB - priceA;
  });

  if (sortValue !== "default") {
    productList.innerHTML = "";
    productElements.forEach(el => productList.appendChild(el));
  }
});

// === ПОВІДОМЛЕННЯ ===
function showNotification(message) {
  const container = document.getElementById("notifications");
  const note = document.createElement("div");
  note.className = "notification";
  note.textContent = message;
  container.appendChild(note);
  setTimeout(() => note.remove(), 3000);
}
// === АВТОРИЗАЦІЯ АДМІНА ===
const adminToggle = document.getElementById("admin-toggle");
const adminLoginModal = document.getElementById("admin-login");
const adminLoginBtn = document.getElementById("admin-login-btn");
let isAdmin = false;

adminToggle.onclick = () => {
  adminLoginModal.style.display = "block";
};

adminLoginBtn.onclick = () => {
  const login = document.getElementById("admin-username").value;
  const pass = document.getElementById("admin-password").value;
  if (login === "admin" && pass === "1234") {
    isAdmin = true;
    adminLoginModal.style.display = "none";
    enableAdminMode();
    showNotification("Ви увійшли як адміністратор");
  } else {
    showNotification("Невірний логін або пароль");
  }
};

function enableAdminMode() {
  document.querySelectorAll(".product").forEach(product => {
    product.classList.add("admin-mode");
    const btn = document.createElement("button");
    btn.textContent = "Видалити товар";
    btn.className = "delete-product";
    btn.onclick = () => {
      product.remove();
      showNotification("Товар видалено");
    };
    product.appendChild(btn);
  });
}
// === РЕЙТИНГ ===
const allProducts = document.querySelectorAll(".product");

allProducts.forEach((product) => {
  const name = product.dataset.name;
  const ratingContainer = product.querySelector(".rating-stars");
  if (!ratingContainer) return;

  const stars = ratingContainer.querySelectorAll("span[data-value]");
  const ratingValue = ratingContainer.querySelector(".rating-value");
  ratingContainer.dataset.name = name;

  let ratings = JSON.parse(localStorage.getItem("ratings") || "{}");
  let currentRating = ratings[name] || { total: 0, count: 0 };
  updateStars();

  stars.forEach((star) => {
    star.addEventListener("click", () => {
      const value = parseInt(star.dataset.value);
      currentRating.total += value;
      currentRating.count += 1;
      ratings[name] = currentRating;
      localStorage.setItem("ratings", JSON.stringify(ratings));
      updateStars();
      showNotification(`Дякуємо! Ви поставили ${value}⭐`);
    });
  });

  function updateStars() {
    const avg = currentRating.count ? currentRating.total / currentRating.count : 0;
    const rounded = Math.round(avg);
    stars.forEach((star) => {
      star.classList.toggle("active", parseInt(star.dataset.value) <= rounded);
    });
    ratingValue.textContent = `(${avg.toFixed(1)})`;
  }
});
// === ІСТОРІЯ ПЕРЕГЛЯНУТИХ ТОВАРІВ ===
let viewedItems = JSON.parse(localStorage.getItem("viewedItems") || "[]");

// Додати при кліку на зображення
document.querySelectorAll(".product img").forEach((img) => {
  img.addEventListener("click", () => {
    const product = img.closest(".product");
    const name = product.dataset.name;
    const price = product.dataset.price;
    const src = img.src;

    // Уникати дублікатів
    viewedItems = viewedItems.filter((item) => item.name !== name);
    viewedItems.unshift({ name, price, src });
    if (viewedItems.length > 5) viewedItems.pop(); // обмежити 5 останніх
    localStorage.setItem("viewedItems", JSON.stringify(viewedItems));
  });
});

// Показ переглянутих
document.getElementById("show-viewed").addEventListener("click", () => {
  const list = document.getElementById("viewed-list");
  list.innerHTML = "";

  if (viewedItems.length === 0) {
    list.innerHTML = "<p>Жодного переглянутого товару</p>";
  } else {
    viewedItems.forEach((item) => {
      const div = document.createElement("div");
      div.className = "viewed-item";
      div.innerHTML = `
        <img src="${item.src}" style="width:100%;height:auto" />
        <h4>${item.name}</h4>
        <p>${item.price} грн</p>
      `;
      list.appendChild(div);
    });
  }

  document.getElementById("viewed-products").style.display = "block";
  showNotification("Показано переглянуті товари");
});
// === ЗВОРОТНІЙ ЗВ’ЯЗОК ===
document.getElementById("feedback-form").addEventListener("submit", function (e) {
    e.preventDefault();
  
    const name = document.getElementById("fb-name").value.trim();
    const email = document.getElementById("fb-email").value.trim();
    const message = document.getElementById("fb-message").value.trim();
  
    if (name && email && message) {
      const feedbacks = JSON.parse(localStorage.getItem("feedbacks") || "[]");
      feedbacks.push({ name, email, message, date: new Date().toLocaleString() });
      localStorage.setItem("feedbacks", JSON.stringify(feedbacks));
  
      this.reset();
      showNotification("Дякуємо! Ваше повідомлення надіслано.");
    } else {
      showNotification("Будь ласка, заповніть всі поля.");
    }
  });
  // === ПОКАЗ ПОВІДОМЛЕНЬ ===
document.getElementById("show-feedbacks").addEventListener("click", () => {
    const list = document.getElementById("feedbacks-list");
    const modal = document.getElementById("admin-feedbacks");
    const feedbacks = JSON.parse(localStorage.getItem("feedbacks") || "[]");
    list.innerHTML = feedbacks.length ? "" : "<p>Немає повідомлень</p>";
    feedbacks.forEach(msg => {
      const div = document.createElement("div");
      div.innerHTML = `<strong>${msg.name}</strong> (${msg.email})<br>${msg.message}<hr>`;
      list.appendChild(div);
    });
    modal.style.display = "block";
  });
  
  // === СИСТЕМА БОНУСІВ ===
  let bonuses = parseInt(localStorage.getItem("bonuses") || "0");
  function updateBonusesDisplay() {
    document.getElementById("bonus-count").textContent = bonuses;
  }
  function addBonuses(amount) {
    bonuses += amount;
    localStorage.setItem("bonuses", bonuses);
    updateBonusesDisplay();
    showNotification(`+${amount} бонусів нараховано!`);
  }
  updateBonusesDisplay();
  
  // Додати до кожного додавання в кошик (приклад):
  document.querySelectorAll(".add-to-cart").forEach(btn => {
    btn.addEventListener("click", () => addBonuses(5));
  });
  
  // === ПОПАП ЗІ ЗНИЖКОЮ ===
  setTimeout(() => {
    document.getElementById("popup-offer").style.display = "block";
  }, 10000);
  // === АДМІН-ПАНЕЛЬ ЗВЕРНЕНЬ ===
document.getElementById("admin-panel-toggle").addEventListener("click", () => {
    const tableContainer = document.getElementById("admin-feedbacks-table");
    const modal = document.getElementById("admin-panel");
    const feedbacks = JSON.parse(localStorage.getItem("feedbacks") || "[]");
  
    if (feedbacks.length === 0) {
      tableContainer.innerHTML = "<p>Немає звернень</p>";
    } else {
      let tableHTML = `<table><tr><th>Ім'я</th><th>Email</th><th>Повідомлення</th><th>Дата</th></tr>`;
      feedbacks.forEach(fb => {
        tableHTML += `<tr><td>${fb.name}</td><td>${fb.email}</td><td>${fb.message}</td><td>${fb.date}</td></tr>`;
      });
      tableHTML += `</table>`;
      tableContainer.innerHTML = tableHTML;
    }
    modal.style.display = "block";
  });
  const express = require("express");
const bodyParser = require("body-parser");
const cors = require("cors");
const fs = require("fs");
const app = express();
const PORT = 3000;

app.use(cors());
app.use(bodyParser.json());

const FEEDBACK_FILE = "feedbacks.json";

// Отримати всі звернення
app.get("/api/feedbacks", (req, res) => {
  if (!fs.existsSync(FEEDBACK_FILE)) return res.json([]);
  const data = fs.readFileSync(FEEDBACK_FILE, "utf-8");
  res.json(JSON.parse(data || "[]"));
});

// Зберегти нове звернення
app.post("/api/feedbacks", (req, res) => {
  const { name, email, message } = req.body;
  const feedbacks = fs.existsSync(FEEDBACK_FILE)
    ? JSON.parse(fs.readFileSync(FEEDBACK_FILE, "utf-8"))
    : [];
  const entry = { name, email, message, date: new Date().toLocaleString() };
  feedbacks.push(entry);
  fs.writeFileSync(FEEDBACK_FILE, JSON.stringify(feedbacks, null, 2));
  res.status(201).json({ success: true });
});

app.listen(PORT, () => {
  console.log(`Server is running on http://localhost:${PORT}`);
});

/* === Клієнтська частина (JavaScript) для відправки звернення ===

fetch("http://localhost:3000/api/feedbacks", {
  method: "POST",
  headers: { "Content-Type": "application/json" },
  body: JSON.stringify({ name, email, message })
})
  .then(res => res.json())
  .then(data => showNotification("Звернення надіслано на сервер!"));
*/
