const express = require("express");
const bodyParser = require("body-parser");
const cors = require("cors");
const fs = require("fs");
const app = express();
const PORT = 3000;

app.use(cors());
app.use(bodyParser.json());

const FEEDBACK_FILE = "feedbacks.json";

// Отримати всі звернення
app.get("/api/feedbacks", (req, res) => {
  if (!fs.existsSync(FEEDBACK_FILE)) return res.json([]);
  const data = fs.readFileSync(FEEDBACK_FILE, "utf-8");
  res.json(JSON.parse(data || "[]"));
});

// Зберегти нове звернення
app.post("/api/feedbacks", (req, res) => {
  const { name, email, message } = req.body;
  const feedbacks = fs.existsSync(FEEDBACK_FILE)
    ? JSON.parse(fs.readFileSync(FEEDBACK_FILE, "utf-8"))
    : [];
  const entry = { name, email, message, date: new Date().toLocaleString() };
  feedbacks.push(entry);
  fs.writeFileSync(FEEDBACK_FILE, JSON.stringify(feedbacks, null, 2));
  res.status(201).json({ success: true });
});

app.listen(PORT, () => {
  console.log(`Server is running on http://localhost:${PORT}`);
});
